=== Match me for BuddyPress ===
Contributors:xpertone 
Tags: match , matchmaking , social networking, activity, profiles, friends, groups, forums, social, community, networks, networking
Requires at least: 4
Tested up to: 5.4.1
Stable tag: trunk
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html


BuddyPress Match adds functionality to match profiles and shows matching percentage on profile.

== Description ==

Are you looking for something which makes it easy to identify the profiles on social network which matches your profile ? Are you looking to find like minded people on BuddyPress Social network in a glance ?

Match me for BuddyPress adds functionality to match profiles and shows matching percentage on profile.

Match percentage is calculated based on number of matching xprofile fields and weightage of each field can be configured from admin.

Plugin displays the match percentage on BuddyPress profile header ,automatically but there is a shortcode available if someone needs to display that in a widget or any other position on site.

Shortcode to display match percentage is [mp_match_percentage]

= For Customization requests send an email at hello@meshpros.com = 

== Installation ==

= From your WordPress dashboard =

1. Visit 'Plugins > Add New'
2. Search for 'Match me for BuddyPress’
3. Activate BuddyPress Match from your Plugins page.

= From WordPress.org =

1. Download Match me for BuddyPress.
2. Upload the ‘mp-bp-match’ directory to your '/wp-content/plugins/' directory, using your favorite method (ftp, sftp, scp, etc...)
3. Activate BuddyPress Match from your Plugins page.

= Once Activated =

Goto Settings > BP Match and set match weightage for each xprofile 

== Frequently Asked Questions ==

= Does it support unlimited profile fields ? =

Yes! 

= Can I request customization =

Yes! the base plugin if FREE of cost but you can always request custom features. if you need some customization or a custom feature please send your requirements at hmk.arain@gmail.com for a quote.

= Can I display the match percentage via shortcode =

Yes!  [mp_match_percentage] is the shortcode for that.

= Where can I get support? =

Via support forum of this plugin

== Pro Version Coming soon ==

1. Switch between simple match (Total Number of fields matched) or Percentage match (total of % of fields matched)
2. In admin Percentage Fields Organized in Groups
3. Exclude fields from calculation
5. Enable Match for selected Roles only.
6. Shortcode to match any 2 users by id or username.
